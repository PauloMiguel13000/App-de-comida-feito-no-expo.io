import React, { Component } from 'react';
import {
  Text,
  StyleSheet,
  ScrollView,
  InputAccessoryView,
  Button,
  View,
  TextInput,
  Image,
  TouchableOpacity,
  Dimensions,
  Permissions,
  Location,
  ScaledSize,
  Alert,
  ImageBackground,
} from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';

class Micle extends Component {
  render() {
    return (
      <View style={StyleSheet.container}>
        <Image
          style={{ width: -200, height: 200 }}
          source={require('./assets/layout azul.png')}
        />

        <TextInput style={styles.input3} placeholder="Digite o alimento" />

        <TouchableOpacity style={{ margin: 20 }} style1={styles.botao}>
          <Button
            title="Pesquise aqui"
            onPress={() => this.props.navigation.navigate('Maps')}
          />

          <Text style={styles.botaoText}> Pesquise aqui </Text>
        </TouchableOpacity>
      </View>
    );
  }
}


const styles = StyleSheet.create({
  input3: {
    marginTop: 100,
    padding: 10,
    width: 300,
    backgroundColor: '#D2A379',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 5,
  },

  botaoText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#263238',
    backgroundColor: 'transparent',
  },
});
const AppNavigator = createStackNavigator({
   Login1,
  HomeScreen: {
    screen: HomeScreen,
  },
  
  
  
},
 
  {
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false,
    } 
});

export default createAppContainer(AppNavigator);
