import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import React, { Component } from 'react';
import {
  Text,
  StyleSheet,
  ScrollView,
  InputAccessoryView,
  View,
  TextInput,
  Image,
  TouchableOpacity,
  Dimensions,
  Permissions,
  Location,
  ScaledSize,
  Alert,
  ImageBackground,
} from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import MapView from 'react-native-maps';

class HomeScreen extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/lanche.png')}
        style={{ width: '100%', height: '100%' }}>
        <View style={styles.container}>
          <Image style={styles.logo} source={require('./assets/logo.png')} />

          <TextInput style={styles.input} placeholder="Digite seu email" />
          <TextInput
            style={styles.input}
            secureTextEntry={true}
            placeholder="Digite sua senha"
          />
          <TouchableOpacity style={styles.button}>
            <Button
              title="Login"
              onPress={() =>
                Alert.alert(
                  'Login',

                  'Confirmar seu login?',
                  [
                    {
                      text: 'Sim',
                      onPress: () => this.props.navigation.navigate('Details'),
                    },

                    {
                      text: 'Não',
                      onPress: () => Alert.alert('voltando para o login'),
                    },
                  ],
                  { cancelable: false }
                )
              }
            />

            <Text style={styles.botaoText}>Coma Rapido 1.0</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    );
  }
}

class Miguel extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/rob.png')}
        style={{ width: '100%', height: '100%' }}>
        <View style={styles1.container}>
          <Image style={styles1.logo} source={require('./assets/Ifome3.png')} />

          <TextInput style={styles1.input1} placeholder="Digite o alimento" />

          <TouchableOpacity style={styles1.botao}>
            <Button style={styles1.botao}
              title="Pesquise aqui"
              onPress={() => this.props.navigation.navigate('Maps')}
            />

            <Text style={styles.botaoText} />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    );
  }
}

class Maps extends Component {
  state = {
    latitude: -12.9708409,
    longitude: -38.4762857,
  };
  render() {
    const { latitude, longitude } = this.state;

    return (
      <View style={styles3.container}>
        <MapView
          initialRegion={{
            latitudeDelta: 0.0042,
            longitudeDelta: 0.0031,
          }}
          style={styles3.mapView}>
          <MapView.Marker
            coordinate={{
              latitude: -12.9708409,
              longitude: -38.4762857,
            }}
          />
        </MapView>
        <ScrollView style={styles3.placesContainer} horizontal>
          <View style={styles3.place} />
          <View style={styles3.place} />
        </ScrollView>
        <TouchableOpacity
          style={{ width: 30, height: 30, margin: 30 }}
          styles={styles.botao}>
          <Button
            title="Ache-se"
            onPress={() => this.props.navigation.navigate('Mapa')}
            loading
            type="outline"
          />
          <Text style={styles.botaoText}>...</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
class Mapa extends Component {
  render() {
    return (
      <MapView
        initialRegion={{
          latitude: -12.9708409,
          longitude: -38.4762857,
          latitudeDelta: 0.0042,
          longitudeDelta: 0.0031,
        }}
        style={styles5.mapView}>
        <MapView.Marker
          coordinate={{
            latitude: -12.9708409,
            longitude: -38.4762857,
          }}
        />
      </MapView>
    );
  }
}

class DetailsScreen extends Component {
  render() {
    return (
      <ImageBackground
        source={require('./assets/lol.png')}
        style={{ width: '100%', height: '100%' }}>
        <View style={{ flex: 1, justifyContent: 'center' }}>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 50 }} />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Pesquisar"
              onPress={() => this.props.navigation.navigate('Miguel')}
            />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Ir para Tela Inicial"
              onPress={() => this.props.navigation.popToTop()}
            />
          </View>

          <View style={{ margin: 20 }}>
            <Button
              title="Voltar"
              onPress={() => this.props.navigation.goBack()}
            />
          </View>
        </View>
      </ImageBackground>
    );
  }
}

const AppNavigator = createStackNavigator(
  {
    Home: {
      screen: HomeScreen,
    },

    Details: {
      screen: DetailsScreen,
    },

    Miguel: {
      screen: Miguel,
    },
    Maps: {
      screen: Maps,
    },
    Mapa: {
      screen: Mapa,
    },
  },

  {
    initialRouteName: 'Home',
  }
);

const styles = StyleSheet.create({
  container: {
    marginTop: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 150,
    height: 150,
    borderRadius: 10,
  },
  input: {
    marginTop: 30,
    padding: 10,
    width: 300,
    backgroundColor: 'rgba(134, 68, 45, 0.4)',
    fontSize: 16,
    fontWeight: 'bold',
    borderRadius: 50,

    borderBottomColor: '#000000',
  },

  botaoText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#263238',
    backgroundColor: 'transparent',
  },
  button: {
    width: 300,
    height: 200,

    margin: 20,
  },
});
const styles1 = StyleSheet.create({
  container: {
    marginTop: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 300,
    height: 300,
    borderRadius: 10,
  },
  botao: {
     margin: 10,
    width: 300,
     height: 200,
   
    
  },

  input1: {
    marginTop: 50,
    padding: 10,
    width: 300,
    backgroundColor: 'rgba(0, 0,0, 0.4)',
    fontSize: 16,
    fontWeight: 'bold',

    justifyContent: 'center',
    alignItems: 'center',
  },
});

const { height, width } = Dimensions.get('window');

const styles3 = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  mapView: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});
const styles5 = StyleSheet.create({
  mapView: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
});

const AppContainer = createAppContainer(AppNavigator);

export default class App extends Component {
  render() {
    return <AppContainer />;
  }
}
